import UIKit

//// Validate URLs
//let strings = ["https://demo0989623.mockable.io/car/1",
//               "https://i.imgur.com/Wm1xcNZ.jpg"]
//let validateURLs = strings.compactMap(URL.init)
//
//// Separate Numbers and Operations
//let mathString: String = "12-37*2/5+44"
//let numbers1 = mathString.components(separatedBy: ["-", "*", "+", "/"]).compactMap(Int.init)
//print(numbers1) // [12, 37, 2, 5, 44]
//
//let views = [innerView,shadowView,logoView]
//let imageViews = views.compactMap{$0 as? UIImageView}
//
//let pairs = zip (points,points.dropFirst())
//let averagePoints = pairs.map {
//           CGPoint(x: ($0.x + $1.x) / 2, y: ($0.y + $1.y) / 2 )}


//func fib(_ n: Int) -> Int {
//    if n == 0 {
//        return 0
//    } else if n == 1 {
//        return 1
//    } else {
//        return fib(n - 1) + fib(n - 2)
//    }
//}
//
//print(fib(6))

//var memo = [Int: Int]()
//
//func fib(_ n: Int) -> Int {
//    if n == 0 { return 0 }
//    else if n == 1 { return 1 }
//  
//    if let result = memo[n] { return result }
//  
//    memo[n] = fib(n - 1) + fib(n - 2)
//    return memo [n]!
//}
//
//fib(6)
//
//func multiply1(_ x: Int, _ y: Int) -> Int {
//  return x*y
//}
//
//func multiply2(_ x: Int) -> (Int) -> Int {
//  return { $0 * x }
//}
//
////Benefit: 1
//multiply2(3)(multiply2(4)(multiply2(5)(6))) //returns 360
////Benefit: 2
//let multiplier = multiply2(2)
//let integerList = 1...100
//let x = integerList.map(multiplier) //returns [2, 4, 6, 8, 10, 12 ...]
//
//
struct ChessPlayer {
    let name: String = "vladik"
    let nickname: String = "hex"
    var age: Int
    var victory: Int?
    var defeat: Int?
    init (age: Int) { self.age = age }
    func printChessPlayerPropery2(){
        print("Player name: \(name) nickname: \(nickname) age: \(age) victory: \(victory!) defeat: \(defeat!)")
    }
}

let vladik = ChessPlayer(age: 22)

