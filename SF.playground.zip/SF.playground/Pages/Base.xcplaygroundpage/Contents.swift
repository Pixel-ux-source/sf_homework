
import UIKit

//let http404Error = (404, "Not Found")
//let (statusCode, statusMessage) = http404Error
//print("The status code is \(statusCode)")
//// Prints "The status code is 404"
//print("The status message is \(statusMessage)")
//// Prints "The status message is Not Found"
//
//let possibleNumber = "123"
//let convertedNumber = Int(possibleNumber)
//
//
//if convertedNumber != nil {
//    print("convertedNumber contains some integer value.")
//}
//
//if let actualNumber = Int(possibleNumber) {
//    print("The string \"\(possibleNumber)\" has an integer value of \(actualNumber)")
//} else {
//    print("The string \"\(possibleNumber)\" couldn't be converted to an integer")
//}
//
//if let convertedNumber {
//    print ("My number is \(convertedNumber)")
//}
//
//let name: String? = nil
//let greeting = "Hello, " + (name ?? "friend") + "!"
//print(greeting)
//
let digitNames = [
    0: "Zero", 1: "One", 2: "Two",   3: "Three", 4: "Four",
    5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"
    ]
let numbers = [0, 2, 9]

//var car = 1
//repeat  {
//    car + (1)
//} while car >= 1


func factorial (_ n: Int) -> Int {
    if n == 1{
        return 1
    } else {
        return factorial(n-1) * n
    }
}
let results2 = factorial(5)
print ("Factorial of 5 is \(results2)")

func fibonaci (_ n: Int) -> Int {
    if n == 0 {
        return 0
    } else if n == 1{
        return 1
    } else {
        return fibonaci(n-1) + fibonaci(n-2)
    }
}

let fib = fibonaci(7)
print ("Fibonaci is \(fib)")

//func sum2 (_ n: Int) -> Int {
//    if n < 10 {
//        return n
//    } else {
//        
//    }
//}

