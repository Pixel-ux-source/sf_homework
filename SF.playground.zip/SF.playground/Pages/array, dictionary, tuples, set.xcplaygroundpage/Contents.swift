//: [Previous](@previous)

import UIKit

//var array: [String] = ["One", "Two", "Three", "Four"]
//print (array)
//array.removeLast()
//print(array)
//array.dropLast()
//print(array)
//array += ["Four", "Five", "Six", "Seven"]
//array.removeLast(2)
//print(array)
//
//
//["file_one.txt", "file_two.txt"].forEach { path in deleteFile(path: path) }
//func deleteFile(path: String) {
//// Удаляем файл ....
//}

//let items = [1,6,9,12,5]
//let newItems = items.reduce(0,+)
//print(newItems)
//let itemsNew = items.filter { $0 % 2 == 0 }
//print(itemsNew)
//let itemsNew2 = items.map { ( $0 * $0 ) }
//print(itemsNew2)

var player = ("Alex", "Sav", 23)
let (firstName, surName, age) = player
print(age)

var array2 = ["One","Two","Three","Four"]
array2.insert("Six", at: 4)
array2 += ["Seven"]

array2 = array2.dropLast()
print(array2)
array2.removeFirst(2)
print(array2)

for (index, value) in array2.enumerated(){
    print("Номер \(index + 1) элемента: \(value)")
}

var array23 = [["One","Two"], ["Three","Four"],["Six","Seven"],["Eight","Nine"],["Ten","Eleven"]]
array23[0][0]
for row in array23 {
    for cell in row {
        print(cell)
    }
}


    

//var numbers32 = [1,2,3,4,5,6,7]
//numbers32.forEach( {print($0)} )
//
//for i in 0..<numbers32.count {
//    print(numbers32[i])
//}


// MARK: НЕ ПОНЯЛ
//let names = ["alan","brian","charlie"]
//let csv = names.reduce("===") {text, name in "\(text),\(name)"}
//
//print(csv) // "===,alan,brian,charlie"
 
// MARK: НЕ ПОНЯЛ почему удаляется [0] & [1]
var numbers = [1, -3, 6, 1, -3, 4, 9, 13, 653, 11, 666, 0, -12, -3223]
var filteredNumbers = numbers.drop(while: {$0 < 6})
print(filteredNumbers)


struct Product {
    let id: String
    let name: String
    let productDescription: String
    let category: String
    let price: Double
    let companyId: Int
}
 
// Массив элементов, которые мы получаем с сервера
let products = [
    Product(id: "4d1d295e-1932-4234-34cd-db32422ds", name: "Цезарь", productDescription: "300 гр", category: "Салаты", price: 320, companyId: 3456121),
    Product(id: "80dosp23-4263-992d-ddle-njpoi2mlw", name: "Борщ", productDescription: "400 гр", category: "Горячее", price: 200, companyId: 3456121),
    Product(id: "skli3112-123a-as31-34cd-poin2koqs", name: "Коктейль", productDescription: "250 мл", category: "Напитки", price: 320, companyId: 3456121)
]
 
// Массив элементов, который ранее был сохранен в БД
var productsDatabase = [
    Product(id: "4d1d295e-1932-4234-34cd-db32422ds", name: "Цезарь", productDescription: "300 гр", category: "Салаты", price: 320, companyId: 3456121),
    Product(id: "80dosp23-4263-992d-ddle-njpoi2mlw", name: "Борщ", productDescription: "400 гр", category: "Горячее", price: 200, companyId: 3456121),
    Product(id: "37289jso-los1-ds13-3321-dspqqwe23", name: "Устрицы", productDescription: "200 гр", category: "Деликатесы", price: 570, companyId: 3456121),
    Product(id: "skli3112-123a-as31-34cd-poin2koqs", name: "Коктейль", productDescription: "250 мл", category: "Напитки", price: 320, companyId: 3456121)
]

for product in productsDatabase {
    if let _ = products.filter( { $0.id == product.id } ).first {
    } else {
        print(product)
    }
}
 
var numbers2 = [1, 3, 6, 1, 3, 4, 9, 13, 653, 11, 666, 0, -12, 3223]
numbers2.sort()

let dictionary: [Int: Int] = [:]

var animals = ["кот": "Вася", "пёс": "Жора", "попугай": "Кеша"]

if let oldValue = animals.updateValue("Мурзик", forKey: "кот") {
  print("Старое значение для ключа кот было \(oldValue).")
    print("Новое значение для ключа кот: \(animals["кот"] ?? "not found")")
}

for (animal, name) in animals {
    print(animal, name)
}

// В первом случае вывод структурой struct Dictionary <String, String>._Variant
let animalsKey = animals.keys
print(animalsKey)

// Второй случай вывод <Array>
let animalsValues = [String] (animals.values)
print(animalsValues)

let setOne: Set <Int> = [1,7,4,8,9,1,0]
let setTwo: Set <Int> = [1,5,6,2,0,3,9]
let setThree: Set <Int> = [1,7,4,8,9,1,0]

setOne.intersection(setTwo).sorted()
setOne.subtracting(setTwo).sorted()
setTwo.subtracting(setOne).sorted()
setThree.symmetricDifference(setOne).sorted()
setThree.symmetricDifference(setTwo).sorted()
setTwo.union(setOne).count
setTwo.union(setOne).sorted()



var daysInMonths = ["31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31"]

let month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]


for i in daysInMonths.indices {
    print ("\(daysInMonths[i]) \(month[i])")
}

let eror404 = (404, "not found")
let eror403: Int = 4

let dictionary1 = ["key": "value", "key2": "value2"]

let dictionary2: [String: String] = ["key": "value", "key2": "value2"]


