import UIKit

    //MARK: Задание 1. Создайте перечисление для ошибок. Добавьте в него 3 кейса:
enum ServerError: Error {
    case badRequest // Ошибка 400
    case notFound   // Ошибка 404
    case internalServerError    // Ошибка 500
}
    //Создаём переменную для хранения ошибки 500
let error: ServerError = .internalServerError
    //Обрабатываем ошибку
do {
    throw error
} catch ServerError.badRequest {
   print("Ошибка 400: Некорректный запрос")
} catch ServerError.notFound {
   print("Ошибка 404: Не найдено")
} catch ServerError.internalServerError {
    print("Ошибка 500: Внутренняя ошибка сервера")
}

    //MARK: Задание 2. Проверка переменных в генерирующей функции с обработкой
    // Создаём переменные
var badRequest = false
var notFound = true
var internalServerError = false
    //Создаём генерирующую функцию, которая проверяет переменные и обрабатывает ошибки
func throwError() throws {
    if badRequest {
        throw ServerError.badRequest
    };
    if notFound {
        throw ServerError.notFound
    };
    if internalServerError {
        throw ServerError.internalServerError
    }
}
    // Обработка ошибок с помощью do try catch
do {
    try throwError()
} catch ServerError.badRequest {
    print("Ошибка 400. Некорректный запрос")
} catch ServerError.notFound {
    print("Ошибка 404. Не найдено")
} catch ServerError.internalServerError{
    print("Ошибка 500. Внутренняя ошибка сервера")
}

    //MARK: Задание 3.
    //Функция, которая принимает на вход два типа, после чего проверяет типы входных и если значения одинаковые = "YES", иначе "No"
func chekType <T, U>(first: T, second: U) {
    let res = type(of: first) == type(of: second) ? "Да!" : "Нет."
    print("Тип первого значения: \(type(of: first)), Тип второго значения: \(type(of: second)), Одинаковые ли типы? \(res)")
}
    //Проверка вывода
chekType(first: "2", second: 3)     // no
chekType(first: "2", second: "2")   // yes

    //MARK: Заданиие 4. Тип входных разный или одинаковый – выбрасывается исключение
    //Создаём перечисление ошибок
enum TypeChekError: Error {
    case different
    case same
}
    //Функция, которая проверяет типы и выбрасывает исключение
func chekType2 <T, U>(first: T, second: U) throws {
    if type(of: first) == type(of: second) {
        throw TypeChekError.same
    }else{
        throw TypeChekError.different
    }
}
    // Обрабатываем ошибку и выводим значение в консоль
do {
    try chekType2(first: 3, second: 3)
} catch TypeChekError.same {
    print("Типы одинаковые")
} catch TypeChekError.different {
    print("Типы разные")
}

    //MARK: Задание 5. Функция принимает два значения, после сравнивает
    // Cоздадим функцию сравнения и снимем ограничения с помощью Equatable
func comparison<T:Equatable> (_ first: T, second: T) {
    let x = first == second ? "совпадают!" : "не совпадают."
    print("Значания \(first) и \(second) – \(x)")
}
    //Проверка через вызов функции
comparison(2, second: 3)



