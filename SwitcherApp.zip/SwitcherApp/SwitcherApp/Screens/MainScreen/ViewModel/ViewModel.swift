//
//  ViewModel.swift
//  SwitcherApp
//
//  Created by Алексей on 26.01.2025.
//

import UIKit

protocol ViewModelProtocol: AnyObject {
    var update: ((ModelCase) -> ())? { get set }
    
    func changeThemeOnDark()
    func changeThemeOnWhite()
}

final class ViewModel: ViewModelProtocol {
    var update: ((ModelCase) -> ())?
    
    func changeThemeOnDark() {
        update?(.switchOn(ModelCase.Model(image: "darkTheme", isOn: true)))
    }
    
    func changeThemeOnWhite() {
        update?(.switchOff(ModelCase.Model(image: "whiteTheme", isOn: false)))
    }
}
