//: [Previous](@previous)

import UIKit

//Вам даны две переменные. Первая дробного типа хранит в себе расстояние в километрах. Вторая целочисленная хранит в себе время в секундах, за которое преодолели данное расстояние.

//Найдите скорость в метрах в минуту.


var distance: Double = 17.2
var time: Int = 1200

func Speed() -> Double {
    return ((distance * 1000) / (Double(time) / 60))
}

let res = Speed()
print(res)


// Даны два целочисленных трехзначных числа. Найти шестизначное, образованное слиянием данных чисел в одно. К примеру из чисел 111 и 222 должно получиться 111222. При этом конечный результат должен иметь тип Int .

var a: Int = 111
var b: Int = 222

func Merge() -> Int {
  return  a * 1000 + b
}

let res2 = Merge()
print(res2)

print(#"6 times 7 is \#(6 * 7)."#)
let greeting = "Guten Tag!"
greeting[greeting.startIndex]
greeting[greeting.index(before: greeting.endIndex)]
let index = greeting.index(greeting.startIndex, offsetBy: 7)
greeting[index]

for i in greeting.indices{
    print("\(greeting[i])", terminator: "")
}

let greeting2 = "Hello, world!"
let index2 = greeting2.firstIndex(of: ",") ?? greeting2.endIndex
let beginning = greeting2[..<index2]

let months = ["January":31, "February":28, "March":31, "April":30, "May":31, "June":30, "July":31, "August":31, "September":30, "October":31, "November":30, "December":31]

months.count

let January = months["January"]

let tuples = (404, "not found", true, 1.2, "a")
tuples.4

var array = [1, 2, 3, 4, 5]
array.count
array.count.description
array.count.isMultiple(of: 5)
array.remove(at: 2)
array.index(before: array.endIndex)



