//
//  UserSettings.swift
//  SwitcherApp
//
//  Created by Алексей on 26.01.2025.
//

import UIKit

protocol UserSettingsProtocol: AnyObject {
    
    func saveBackgroundColor(switcherIsOn: Bool)
    func loadBackgroundColor(view: UIView)
    
    func saveImage(switcherIsOn: Bool)
    func loadImage(newImageView: UIImageView)

    func saveSwitcherPos(switcherIsOn: Bool)
    func loadSwitcherPos(switcher: UISwitch)

}

private enum KeySwitcher: String {
    case colorName, imageName, switcherPos
}

final class UserSettings: UserSettingsProtocol {
    
    private let defaults = UserDefaults.standard
    // MARK: — SAVE_BG
    func saveBackgroundColor(switcherIsOn: Bool) {
        switch switcherIsOn {
        case true:
            defaults.set("bgDark", forKey: KeySwitcher.colorName.rawValue)
        case false:
            defaults.set("bgWhite", forKey: KeySwitcher.colorName.rawValue)
        }
    }
    // MARK: — LOAD_BG
    func loadBackgroundColor(view: UIView) {
        let savedData = defaults.string(forKey: KeySwitcher.colorName.rawValue)
        view.backgroundColor = UIColor(named: savedData ?? "bgWhite")
    }
    // MARK: — SAVE_IMG
    func saveImage(switcherIsOn: Bool) {
        switch switcherIsOn {
        case true:
            defaults.set("blackTheme", forKey: KeySwitcher.imageName.rawValue)
        case false:
            defaults.set("whiteTheme", forKey: KeySwitcher.imageName.rawValue)
        }
    }
    // MARK: — LOAD_IMG
    func loadImage(newImageView: UIImageView) {
        let dataSaved = defaults.string(forKey: KeySwitcher.imageName.rawValue)
        newImageView.image = UIImage(named: dataSaved ?? "whiteTheme")
    }
    // MARK: — SAVE_SWITCH
    func saveSwitcherPos(switcherIsOn: Bool) {
        defaults.set(switcherIsOn, forKey: KeySwitcher.switcherPos.rawValue)
    }
    // MARK: — LOAD_SWITCH
    func loadSwitcherPos(switcher: UISwitch) {
        let dataSaved = defaults.bool(forKey: KeySwitcher.switcherPos.rawValue)
        switcher.isOn = dataSaved
    }
}
