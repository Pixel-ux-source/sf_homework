
import UIKit

//protocol Dog {
//    var name: String { get }
//    var paws: Int { get }
//    var weight: Float { get set }
//    var isHappy: Bool { get set }
//    var commands: [String] { get set }
//}
//
//class Corgi: Dog {
//    private(set)var name: String = "Bublik"
//    private(set)var paws: Int = 4
//    var weight: Float = 10.0
//    var isHappy: Bool = true
//    var commands: [String] = []
//}
//let dog = Corgi()
//print(dog.name)
//dog.weight = 9.0
//dog.commands = ["sit", "roll over"]
//print(dog.commands)
//print(dog.weight)

//class Dog: SquadCanids {
//    private(set) var ears: Int = 2
//    private(set) var eys: Int = 2
//    private(set) var tail: Int = 1
//    private(set) var fangs: Int = 2
//    
//    init (dogNickname: String ) {
//        self.dogNickname = dogNickname
//    }
//    var dogNickname: String
//    var nickname: String {
//        get {
//            return dogNickname
//        }
//        set {
//            dogNickname = newValue
//        }
//    }
//    
//}
//
//protocol SquadCanids {
//    var ears: Int { get }
//    var eys: Int { get }
//    var tail: Int { get }
//    var fangs: Int { get }
//}
//
//protocol Commands {
//    var commands: [String] { get set }
//}
//
//protocol Bark {
//    var bark: Bool { get }
//}
//
//class Bobtail: Dog, Commands, Bark {
//    var commands: [String] = []
//    private(set)var bark: Bool = true
//    
//    init (dogNickname: String, commands: [String]) {
//        self.commands = commands
//        super.init (dogNickname: dogNickname)
//    }
//}
//
//let bobtailJack = Bobtail (dogNickname: "Jack", commands: ["sit", "roll over"])
//
//
//switch bobtailJack.bark {
//case true:
//    print("""
//    Пёс по имени \(bobtailJack.dogNickname) знает команды \(bobtailJack.commands)
//    \(bobtailJack.dogNickname), имеет \(bobtailJack.ears) уха, \(bobtailJack.eys) глаза, \(bobtailJack.fangs) клыка и \(bobtailJack.tail) хвост.
//    Этот пёс имеет голос! 
//    Ваш питомец абсолютно здоров, поздравляю!
//    """)
//
//case false:
//    print("""
//    Пёс по имени \(bobtailJack.dogNickname) знает команды \(bobtailJack.commands)
//    \(bobtailJack.dogNickname), имеет \(bobtailJack.ears) уха, \(bobtailJack.eys) глаза, \(bobtailJack.fangs) клыка и \(bobtailJack.tail) хвост.
//    Этот пёс к сожалению не имеет голоса :(
//    Ваш питомец заболел, его нужно обследовать!
//    """)
//}

//protocol SomeProtocol {
//    init(someText: String, someEnum: SomeEnum)
//}
//enum SomeEnum {
//    case text
//    case number
//}
//class SomeClass: SomeProtocol {
//    let someText: String
//    let someEnum: SomeEnum
//    required init(someText: String, someEnum: SomeEnum) {
//        self.someText = someText
//        self.someEnum = someEnum
//    }
//}
//
//class SubClass: SomeClass{
//    let subClassText: String
//    let subClassEnum: SomeEnum
//    
//    required init(someText: String, someEnum: SomeEnum) {
//        fatalError("init(someText:someEnum:) has not been implemented")
//    }
//}

////Создайте протокол, который будет предписывать реализовать инициализатор, два свойства и метод.
//protocol HeroProtocol {
//    init (name: String, age: Int)
//    var name: String { get }
//    var age: Int { get set }
//    
//    func printInfo()
//}
//
////В инициализатор будет передаваться имя нашего героя из фильма John Wick и его возраст. Свойства же будут принимать эти поля из инициализатора. А метод будет выводить имя и возраст нашего героя.
//
//extension HeroProtocol {
//    func printInfo() {
//    print("Нашего героя зовут \(name), и его возраст \(age).")
//    }
//}
//
//class Hero: HeroProtocol {
//    required init(name: String, age: Int) {
//        self.name = name
//        self.age = age
//    }
//    var name: String
//    var age: Int
//}
//
//let jhon: Hero = Hero(name: "Jhon Wick", age: 42)
//jhon.printInfo()

//protocol MyDelegate {
//    func changeStruing(_ text: String)
//}
//
//class General: MyDelegate {
//    var generalText: String = "Hello World"
//    
//    func changeStruing(_ text: String) {
//        generalText = text
//    }
//}
//
//class Secondary {
//    var delegate: MyDelegate!
//}
//
//let general: General = General()
//print (general.generalText)
//
////Теперь создайте экземпляр класса Secondary с именем secondary и вызовите переменную delegate, а затем передайте ей экземпляр класса General, тем самым вы получите доступ к данным из general.
//
//let secondary: Secondary = Secondary()
//secondary.delegate = general
//secondary.delegate.changeStruing("Hello Delegate")
//print(general.generalText)
//
//
////Создайте протокол SomeMyDelegate, у которого есть метод MyDelegateprintSomeText(someText: String)
//
//protocol SomeMyDelegate {
//    func printSomeText(someText: String)
//}
//
////Далее создайте класс SomeClassImplementsDelegate, который будет реализовывать протокол SomeMyDelegate, а метод протокола должен выводить someText + "Class Implements Delegate" на консоль.
//
//class SomeClassImplementsDelegate: SomeMyDelegate {
//    func printSomeText(someText: String) {
//        print(someText + "I am happy")
//      }
//}
//
////Следующий шаг: создайте класс SomeClassUsingDelegate, который будет иметь переменную с именем delegate и метод simulateAction(text: String), который будет передавать этот текст непосредственно делегируемому методу delegate. printSomeText(someText: text)
//
//class SomeClassUsingDelegate {
//    var delegate: SomeMyDelegate!
//    func simulateAction(text: String) {
//        delegate.printSomeText(someText: text)
//    }
//}
//
//
//let implementsDelegate: SomeClassImplementsDelegate = SomeClassImplementsDelegate()
//let usingDelegate: SomeClassUsingDelegate = SomeClassUsingDelegate()
//
//usingDelegate.delegate = implementsDelegate
//usingDelegate.simulateAction(text: "I am posting new text")


protocol FullyNamed {
    var fullName: String { get }
}

class Starship: FullyNamed {
    var prefix: String?
    var name: String
    init(name: String, prefix: String? = nil) {
        self.name = name
        self.prefix = prefix
    }
    var fullName: String {
        return (prefix != nil ? prefix! + " " : "") + name          // a ? b : c
    }
}

var ncc1701 = Starship(name: "Enterprise", prefix: "USS")
print (ncc1701.fullName)


