//
//  SwitcherAppTests.swift
//  SwitcherAppTests
//
//  Created by Алексей on 26.01.2025.
//

import Testing
@testable import SwitcherApp

struct SwitcherAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
