//
//  ViewController.swift
//  SwitcherApp
//
//  Created by Алексей on 26.01.2025.
//

import UIKit

final class ViewController: UIViewController {
    // MARK: — OBJECTIVE
    private let viewModel = ViewModel()
    private let userSettings = UserSettings()
    
    // MARK: — MAIN_IMAGE_VIEW
    let mainImageView: UIImageView = {
        let image = UIImageView()
        image.translatesAutoresizingMaskIntoConstraints = false
        image.contentMode = .scaleAspectFill
        image.clipsToBounds = true
        return image
    }()
    
    // MARK: — SWITCH_BTN
    let switcher: UISwitch = {
        let switcher = UISwitch()
        switcher.translatesAutoresizingMaskIntoConstraints = false
        switcher.isOn = false
        return switcher
    }()

    // MARK: — LIFE_CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        btnAction()
        addImageOnView()
        addSwitchOnView()
        getState()
        loadSavedData()
    }

    // MARK: — BTN_ACTION
    private func btnAction() {
        switcher.addTarget(self, action: #selector(self.switchValueChanged), for: .touchUpInside)
    }
    
    // MARK: — OBJC_METHOD
    @objc private func switchValueChanged() {
        switch switcher.isOn {
        case true:
            mainImageView.image = UIImage(named: "blackTheme")
            view.backgroundColor = .bgDark
            saveData()
        case false:
            mainImageView.image = UIImage(named: "whiteTheme")
            view.backgroundColor = .bgWhite
            saveData()
        }
    }
    
    // MARK: — SAVE_DATA
    private func saveData() {
        userSettings.saveImage(switcherIsOn: switcher.isOn)
        userSettings.saveSwitcherPos(switcherIsOn: switcher.isOn)
        userSettings.saveBackgroundColor(switcherIsOn: switcher.isOn)
    }
    
    // MARK: — LOAD_DATA
    private func loadSavedData() {
        userSettings.loadBackgroundColor(view: self.view)
        userSettings.loadSwitcherPos(switcher: switcher)
        userSettings.loadImage(newImageView: mainImageView)
    }
    
    // MARK: — ADD_IMAGE_ON_VIEW
    private func addImageOnView() {
        view.addSubview(mainImageView)
        
        NSLayoutConstraint.activate([
            mainImageView.topAnchor.constraint(equalTo: view.topAnchor, constant: 40),
            mainImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: -10),
            mainImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 10),
            mainImageView.heightAnchor.constraint(equalToConstant: 270)
        ])
    }
    
    // MARK: — ADD_SWITCH_ON_VIEW
    private func addSwitchOnView() {
        view.addSubview(switcher)
        
        NSLayoutConstraint.activate([
            switcher.topAnchor.constraint(equalTo: mainImageView.bottomAnchor, constant: 10),
            switcher.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    // MARK: — UPDATE_VIEW
    private func updateView(state: ModelCase.Model?) {
        guard let state = state else { return }
        mainImageView.image = UIImage(named: state.image)
        switcher.isOn = state.isOn
    }
    
    // MARK: — GET_STATE
    private func getState() {
        viewModel.update = { [weak self] data in
            guard let self = self else { return }
            switch data {
            case .switchOn(let switchOn):
                self.updateView(state: switchOn)
            case .switchOff(let switchOff):
                self.updateView(state: switchOff)
            }
            
        }
    }
}

