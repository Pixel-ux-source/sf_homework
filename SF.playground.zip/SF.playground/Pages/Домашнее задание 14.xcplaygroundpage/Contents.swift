
import UIKit

//Есть магазин по доставке собачьей еды и игрушек. В нём можно заказать некоторые продукты питания и игрушки. Можно оформить заказ на какой-то адрес, а также на определённые дату и время.

//протокол FeedDeliveryDelegate, который обязывает реализовать три метода feedDeliveryByAddres, feedDeliveryTime и ordered;
//два перечисления: одно отвечает за еду DogFeed, а второе – за игрушки DogToys;
//класс FeedShopHappyDog, который и реализует наш делегат.
//класс WebsiteForOrderingFeedShopHappyDog, который имитирует действия пользователя. В нём же содержится переменная делегата.

protocol FeedDeliveryDelegate: AnyObject {
    func feedDeliveryByAddres (adres: String, flat: Int) // string?
    func feedDeliveryTime (data: String, time: String) // suka, int znachenie?
    func ordered (feed: DogFeed?, toys: DogToys?)  // Enums?
}

enum DogFeed: String {
    case dogFood = "Педигри"
    case dogBone = "Собачья кость"
    case dogTreat = "Печенья"
}

enum DogToys: String {
    case dogBall = "Шарик"
    case dogLeash = "Ошейник"
    case dogBone = "Игрушечная кость"
}

class FeedShopHappyDog:FeedDeliveryDelegate {
    func feedDeliveryByAddres (adres: String, flat: Int) {
        print("Адрес заказа: \(adres), квартира № \(flat)")
    }
    
    func feedDeliveryTime (data: String, time: String) {
        print("Доставим \(data) в \(time)")
    }
    
    func ordered (feed: DogFeed?, toys: DogToys?) {
        if feed != nil {
            switch feed {
            case .dogFood:
                print("Ваш заказ - \(DogFeed.dogFood.rawValue)")
            case .dogBone:
                print("Ваш заказ - \(DogFeed.dogBone.rawValue)")
            case .dogTreat:
                print("Ваш заказ - \(DogFeed.dogTreat.rawValue)")
            case .none:
                return
            }
        }
        
        if toys != nil {
            switch toys {
            case .dogBall:
                print("Ваш заказ - \(DogToys.dogBall.rawValue)")
            case .dogBone:
                print("Ваш заказ - \(DogToys.dogBone.rawValue)")
            case .dogLeash:
                print("Ваш заказ - \(DogToys.dogLeash.rawValue)")
            case .none:
                return
            }
        }
    }
}

class WebsiteForOrderingFeedShopHappyDog {
    weak var delegate: FeedDeliveryDelegate?
    func adres (text: String, text2: Int) {
        delegate?.feedDeliveryByAddres(adres: text, flat: text2)
    }
    func time (d:String, t: String) {
        delegate?.feedDeliveryTime(data: d, time: t)
    }
    func ordered (v1: DogFeed?, v2:DogToys? ) {
        delegate?.ordered(feed: v1, toys: v2)
    }
}

let shop = FeedShopHappyDog()

let web = WebsiteForOrderingFeedShopHappyDog()
web.delegate = shop

web.adres(text: "Moskow, Lenina 15", text2: 321)
web.time(d: "12 октября", t: "12:30")
web.ordered(v1: .dogBone, v2: .dogBall)




protocol Close{
    var close: String { get }
    
}

class MyProtocol: Close {
    var close: String = "Close"
    
}

let myProtocol: Close = MyProtocol()
print(myProtocol.close)

