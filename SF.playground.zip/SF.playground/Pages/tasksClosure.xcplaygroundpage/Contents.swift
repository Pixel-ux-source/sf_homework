import UIKit

// Составить замыкание для поиска четырёхзначных чисел, которые при делении на 133 дают в остатке 125, а при делении на 134 дают в остатке 111
if true {
    let closure = { () -> ([Int]) in
        var nums = [Int]()
        
        for num in 1000 ... 9999 {
            if num % 133 == 125 && num % 134 == 111 { nums.append(num) }
        }
        return nums
    }
}

//let checkWord = { (bigWord:String, smallWord:String) -> Bool in
//    
//    let bigWord = bigWord.lowercased()
//    let smallWord = smallWord.lowercased()
//    
//    return true
//}



//  Необходимо реализовать функцию, которая будет проверять, правильно ли пользователь заполнил все данные, и регистрировать его в приложении.
//  Имя пользователя (обязательное поле регистрации; требование к данным: имя не должно быть пустым);
//  Фамилия пользователя (необязательное поле регистрации);
//  Возраст пользователя (обязательное поле регистрации; возраст должен быть больше ноля);
//  Согласие с лицензионным соглашением (обязательное поле регистрации).

var nameUser: String = ""
var surnameUser: (String?)
var ageUser: Int = 0
var licenseUser: Bool = false

// Далее необходимо реализовать функции, которые будут сохранять введённые данные пользователя. Для каждого поля нужно создать отдельную функцию, которая будет сохранять данные в созданные переменные.

func enterName (_ text: String) {
    nameUser = text
}

func enterSurname (_ text: String?) {
    surnameUser = text
}

func enterAge(_ number: Int) {
    ageUser = number
}

func enterLicense (_ value: Bool) {
    licenseUser = value
}

//После этого следует создать функции, которые будут проверять, правильно ли пользователь ввёл все данные. Здесь будет действовать такое же правило: на каждую переменную — отдельная функция.

func isValidateName() -> Bool {
    nameUser.isEmpty == false
}

func isValidateSurname() -> Bool {
    true
}

func isValidateAge() -> Bool {
    ageUser > 0
}

func isValidateLicense() -> Bool {
    licenseUser
}

func registerUser() -> Bool {
    if !isValidateName () {
        print("Check your name")
        return false
    }
    
    if !isValidateAge() {
        print("Check your age")
        return false
    }
    
    if !isValidateLicense () {
        print("Check License")
        return false
    }
    
    if !isValidateSurname() {
        print("Check your surname")
        return false
    }
    return true
}

enterAge(2)
enterName("ww")
enterLicense(true)
enterSurname("zz")

if registerUser () {
    print("Вы успешно зарегистрированы!")
}

//MARK: ЗАМЫКАНИЯ

let closureHello = { print("Hello world!") }

closureHello ()
type(of: closureHello)

//Что я тут наделал?
//let closureSt = { (txt: String, closure: (String) -> ()).self }
//closureSt()


// Мой вариант
func funcStr (_ text: String, closure: (String) -> (String)) {
    print(text)
}

funcStr("hi!") { text in
    let result = String (text)
    print(result)
    return result
}

//Ответ
let closurePrintMessage = { (message: String) in
    print(message)
}

closurePrintMessage("Этот текст будет выведен на консоль")

let closure22: (String) -> () = { print($0) }

//Мой вариант решения
func sum(_ num1: Int, _ num2: Int, closure: (Int, Int) -> Int) {
    let sumNum = Int (num1 + num2)
    print (sumNum)
}
sum(3, 2) { num1, num2 in
    num1 + num2
}
type(of: sum)
// Почему получается такая хрень?

//Ответ
let closureSumNum = { (_ a: Int, _ b: Int) in
return a + b}

print (closureSumNum (6,9))
type(of: closureSumNum)
// Как лучше делать через func или (||) let

//https://vk.com/topic-212947800_49432522
//1. Написать фунĸцию, ĸоторая ничего не возвращает и принимает тольĸо один ĸлоужер, ĸоторый ничего не принимает и ничего не возвращает. Фунĸция должна просто посчитать от 1 до 10 в циĸле и вывести на экран эти цифры.
//После выхода из цикла вызвать ĸлоужер.
//Добавьте printы перед циклом (начало цикла), после цикла (конец цикла) и вызов клоужера.
//В самом клоужере исполняется просто какой-то код.
//Поиграйтесь с размещением этого клоужера, что его можно вызвать хоть два раза, или в любом другом месте функции.

func Cycle (closure: ()-> ()) {
   print("Начало цикла")
    for n in 1...10 {
        print(n)
    }
    print("Конец цикла")
}

Cycle {
    print ("Вызов Closure")
}

//Прочитайте главу в методичке. Создайте массив Интов, используя метод сортировки массивов sorted, отсортируйте массив интов по возрастанию и убыванию. Пример поĸазан в методичĸе, использовать именно как в методичке.

var nn: String = "ss"
print (nn, terminator: "2 ") // чем это отличается от того что ниже
print ("2\(nn)")
//UPD: ОАОАОАОА он объединил два принта!!!

let anotherPi = 3 + 0.14159
type(of: anotherPi)

var ff = 2
type(of: ff)


// MARK: ЗАПУТАЛСЯ
// Функция curry: Напишите функцию curry, которая принимает функцию с двумя аргументами (A, B) -> C и возвращает функцию (A) -> (B) -> C.

//func curry (_ a: (Int, Int)) -> Bool {
//    return true
//}
//func curry (_ a: (Int), _ b: (Int)) -> Bool {
//    return { a in
//        return { b in
//            return true
//        }
//    }
//}
//
//func curry (_ func: @escaping (_ function: (Int, Int)) -> (Bool) -> (_ a: (Int), _ b: (Int)) -> Bool) {
//    return { a in
//        return { b in
//            return true
//        }
//    }
//}
//
//func curry<A, B, C>(_ function: @escaping (A, B) -> C) -> (A) -> (B) -> C {
//    return { a in
//        return { b in
//            return function(a, b)
//        }
//    }
////}

let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

func backward(_ s1: String, _ s2: String) -> Bool {
    return s1 > s2
}
var reversedNames = names.sorted(by: backward)
backward("Daniella", "Ewa")

//Также можно выразить иным способом

reversedNames = names.sorted(by: { (s1: String, s2: String) -> Bool in
    return s1 > s2
})

//Сократим ещё больше

reversedNames = names.sorted(by: { s1, s2 in return s1 > s2 } )

//Оказывается нет тому предела, сократим ещё)

reversedNames = names.sorted(by: { $0 > $1 } )

//"На самом деле есть еще более короткий способ написать приведенное выше выражение замыкания."
//UPD: Вот тут я знатно офигел

reversedNames = names.sorted(by: >)

//Метод map(_:)

let digitNames = [
    0: "Zero", 1: "One", 2: "Two",   3: "Three", 4: "Four",
    5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"
]
let numbers = [16, 58, 510]

let strings = numbers.map { (number) -> String in
    var number = number
    var output = ""
    repeat {
        output = digitNames[number % 10]! + output
        number /= 10
    } while number > 0
    return output
}
// strings is inferred to be of type [String]
// its value is ["OneSix", "FiveEight", "FiveOneZero"]
print (strings)

// Прочитайте главу в методичке. Создайте массив Интов, используя метод сортировки массивов sorted, отсортируйте массив интов по возрастанию и убыванию. Пример поĸазан в методичĸе, использовать именно как в методичке.

let arrayInt = [22, 102, 10, 131]

func backward (_ i1: Int, _ i2: Int, _ i3: Int, _ i4: Int) -> Bool {
    return i1 > i2 && i2 > i3 && i3 > i4
}
var reservedInt = arrayInt.sorted(by: >)

let up = arrayInt.sorted(by: {$0 > $1} )
let down = arrayInt.sorted(by: {$1 > $0} )

print (up)
print (down)
backward(10, 22, 102, 131)
backward(131, 102, 22, 10)
