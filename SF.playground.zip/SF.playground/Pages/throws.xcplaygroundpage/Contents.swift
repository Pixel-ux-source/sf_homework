
import UIKit

enum AutoError: Error {
 
    case isLost // заблудился
    case lowBattery // низкая батарея
    case brokeAutoDrive // проблемы с управлением машины
 
}

var isLost: Bool = false
var lowBattery: Bool = true
var brokeAutoDrive: Bool = false

func autoDrive () throws { if isLost { throw AutoError.isLost};  if lowBattery { throw AutoError.lowBattery }; if brokeAutoDrive { AutoError.brokeAutoDrive } }

do {
    if isLost {
        throw AutoError.isLost
    }
 
    if lowBattery {
        throw AutoError.lowBattery
    }
 
    if brokeAutoDrive {
        throw AutoError.brokeAutoDrive
    }
} catch AutoError.isLost {
    print("Вы заблудились! Включаю GPS")
} catch AutoError.lowBattery {
    print("Батарея садится! Ближайшая станция подзарядки через 1 км 300 м")
} catch AutoError.brokeAutoDrive {
    print("Режим автопилота поврежден. Переходим в режим ручного управления!")
}

do {
    try autoDrive()
} catch AutoError.isLost {
    print("Вы заблудились! Включаю GPS")
} catch AutoError.lowBattery {
    print("Батарея садится! Ближайшая станция подзарядки через 1 км 300 м")
} catch AutoError.brokeAutoDrive {
    print("Режим автопилота поврежден. Переходим в режим ручного управления!")
}

var batteryCharge = 10

do {
    if lowBattery {
        throw AutoError.lowBattery
    }
// Ловим сгенерированную ошибку, когда заряд батареи меньше 15
} catch AutoError.lowBattery where batteryCharge < 15  {
    print("Батарея садится! Ближайшая станция подзарядки через 300 м")
}

func addition<T: Numeric> (_ a: T, _ b: T) -> T {
    return a + b
}

struct IntStack {
    var items = [Int]()
    mutating func push(_ item: Int) {
        items.append(item)
        print(items)
    }
    mutating func pop() -> Int {
        return items.removeLast()
    }
}

var ex = IntStack()
ex.items = [1,2,3,7,9,20]
ex.push(2)
ex.pop()
ex.pop()


//struct – value type (Типовое значение)
//class – reference type (Ссылочное значение)

//func someFunc<T, E>(a: T, b: E) -> Void {
//    /// some code
//}
// 
//print ( someFunc(a: "a", b: 5.2) )
 

struct Stack<T> {
    var items = [T]()
    init() {}
    init (_ elements: T...) {
        self.items = elements
    }
    mutating func push(_ item: T) {
        items.append(item)
        print(items)
    }
    mutating func pop() -> T {
        return items.removeLast()
    }
}

var ex2 = Stack(1,2,3,4)
ex2.push(5)
ex2.pop()

extension Stack {
    var topItem: T? {
        return items.isEmpty ? nil : items.last     // то же самое что и items[items.count - 1]
    }
}

ex2.topItem
ex2.items


func findIndex<T: Equatable>(array: [T], valueToFind: T) -> Int? {
    for (index, value) in array.enumerated() {
        if value == valueToFind {
            return index
        }
    }
return nil
}

print ( findIndex(array: ["One", "Two", "Three", "Four", "Five"], valueToFind: "Four") ?? "Not found" )
