//
//  Model.swift
//  SwitcherApp
//
//  Created by Алексей on 26.01.2025.
//

import Foundation

enum ModelCase {
    case switchOn(Model), switchOff(Model)
    
    struct Model {
        var image: String
        var isOn: Bool
        
        init(image: String, isOn: Bool) {
            self.image = image
            self.isOn = isOn
        }
    }
}
