
import UIKit

// MARK: EXAMPLE 1
// Создано 2 одинаковых кортежа
let peopleOne = (age: 23, name: "Adam", height: 80.8)
let peopleTwo = (age: 23, name: "Adam", height: 80.8)

// Инициализация двумя способами: по индексу(.0) и по параметру(.age)
peopleOne.0
peopleTwo.age
peopleOne.1
peopleTwo.name
peopleOne.2
peopleTwo.height

// MARK: EXAMPLE 2
// Создан массив интов с днями месяцев
var daysInMonths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

// Иттерация для вывода каждого элемента массива
for days in daysInMonths {
    print(days)
}

// Создан новый массив стринг значений месяцев
let month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]

// Проводим иттерацию для индекса по каждому индексу массива month от [0] до конца, исключая последнее число
for index in 0..<month.count {
    print("\(daysInMonths[index]) \(month[index])")
}

// Создаём новый массив кортежей, где есть месяц и количество дней
let monthWithDays = [(month:"January", day:31), (month:"February", day:28), (month:"March", day:31), (month:"April", day:30), (month:"May", day:31), (month:"June", day:30), (month:"July", day:31), (month:"August", day:31), (month:"September", day:30), (month:"October", day:31), (month:"November", day:30), (month:"December", day:31)]

// Иттерация для вывода каждого параметра кортежа в массиве
for (month, day) in monthWithDays {
    print ("В месяце \(month) – \(day) дней")
}

// Создаём иттерацию по сортированным без изменения исходного массива индексам, после чего выводим отдельно дни и месяца в промежутке от первого индекса до последнего.
for i in daysInMonths.indices.sorted(by: > ) {
    print ("\(daysInMonths[i...i]) \(month[i...i])")        // К сожалению, не понимаю как убрать массив на одно значение :(
}
                                                            // UPD: Является ли данный способ решения адекватным? Или данный формат кода тяжело читаем и можно было решить проще и лучше?
// Проверяем исходность массивов:
daysInMonths
month

// Создаем константу для рандомизации числа месяца
let randomDay = Int.random(in: 1...31)
// Создаём словарь (Dictionary) с общим количеством прошедших дней на конец месяца
let dayLater = ["January": 31, "February": 59, "March": 90, "April": 120, "May": 151, "June": 181, "July": 212, "August": 243, "September": 273, "October": 304, "November": 334, "December": 365]
// Создаём константу для рандомизации номера месяца
let randomMonthIndex = Int.random(in: 1...12)
// Меняем номер месяца на его название
let randomMonth =  month[randomMonthIndex - 1]
// Обращаемся к словарю и ищем сколько дней прошло в году
let dayLaterKey = dayLater[randomMonth]
// Обращаемся к кортежу и ищем сколько максимум дней в данном месяце
let dayMax = monthWithDays[randomMonthIndex - 1].day

// Создаём условие, если наше число месяца подоходит под максимальное количество дней, то выводим расчёт, иначе пишем об отсутствии дня
if randomDay <= dayMax {
    print ("Сегодня \(randomDay) \(randomMonth). До конца года осталось \(365 - (dayLaterKey! - randomDay)) дней!")
} else {
    print ("Такой даты не существует! В \(randomMonth) всего \(dayMax) дней")
}

// MARK: EXAMPLE 3
// Создаём словарь (Dictionary) – журнал, где Имя Фамилия студента - это ключ (key), а оценка за экзамен – это значение (value)
var journal = ["Alex Savelev": 4, "Ivan Ivanov": 3 , "Vlad Jirnoy": 2, "Vladimir Subbotin": 5, "Kirill Smirnov": 2]

// Повышаем оценку студенту
journal["Kirill Smirnov"] = 4

// Создаём иттерацию для фильтрации студентов по оценке (value в journal). Выводим сообщение в соответствии с результатом.
for (name, mark) in journal {
    if mark >= 4 {
        print ("\(name), ваша оценка \(mark), хорошая работа, поздравляем!")
    } else if mark == 3 {
        print ("\(name), ваша оценка \(mark), работа удовлетворительного качества, могли бы и лучше, но уже результат, поздравляем!")
    } else {
        print ("\(name), ваша оценка \(mark)!! Вы не сдали, учите лучше!")
    }
}

// Зачисляем к нам в группу новых студентов(key)! Сразу проводим тестироваине и получаем также результат за экзамен (value)
journal["Ivan Budko"] = 4
journal["Aleksandr Romanov"] = 5
journal["Vladimir Orlov"] = 3

// К сожалению у Влада самая низкая успеваемасть, нам придётся отчислить его :(
journal.removeValue(forKey: "Vlad Jirnoy")

// Теперь посчитаем средний балл группы и выведем в консоль
let sum = (journal.values.reduce(0, +) / journal.count)
print ("Средний балл группы = \(sum)")
