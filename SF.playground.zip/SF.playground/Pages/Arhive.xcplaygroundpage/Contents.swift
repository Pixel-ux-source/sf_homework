import UIKit

// Название лояльности с накоплением баллов за покупки
let namePointLoyality = "point"
// Название лояльности с накоплением баллов за приобретение кофе
let nameVisitLoyality = "visit"
 
// Название лояльности, которая есть у пользователя
let nameLoyality = "point"
// Генерация токена Пользователя (он же номер телефона)
let randomIntUser = Int.random(in: 89000000000..<89999999999)
let userIdLoyality = String(randomIntUser)
// Генерация токена Кофемана (он же номер телефона)
let randomIntCoffee = Int.random(in: 89000000000..<89999999999)
let coffeeIdLoyality = String(randomIntCoffee)

let idUser = userIdLoyality

// Количество приобретенного кофе
let countGradeValue = 0
// Баланс в рублях
let balance = 500
// Грэйд - в зависимости от уровня пользователя выдается определенная скидка в процентах
let grade = 5
// Генерация чека (кост)
let randomIntCost = Int.random(in: 100..<20000)
// Стоимость продукта или кофе
let cost = randomIntCost
// Скидочный баланс в коинах
let balanceCoin = 0
// Расчёт коинов с покупки
var coin = Double(cost) * Double(grade/100)

// Выполним определение системы лояльности
switch idUser {
case userIdLoyality:
    print("Ваша система лояльности Покупатель")
    print("Ваша скидка: \(grade) %")
    print("Баланс: \(balance) руб")
    print("Номер клиента: \(userIdLoyality)")
    print("Сумма заказа: \(cost)")
    // Пробиваем товар и проводим транзакцию
    // Если хватает средств, то...
    if (cost <= balance) {
        balance - cost
        print ("Cтоимость заказа: \(cost) руб. Спасибо за покупку! Приходите ещё)")
    // Если не хватает средств, то...
    } else if (cost > balance){
    print ("Недостаточно средств. Попробуйте другую карту.")
}
case coffeeIdLoyality:
    print("Ваша система лояльности Кофеман :)")
    print("Кофе: \(countGradeValue)")
    print("Номер клиента: \(coffeeIdLoyality)")
    print("Сумма заказа: \(cost)")
    if (cost <= balance) {
        balance - cost
        print ("Cтоимость заказа: \(cost) руб. Спасибо за покупку! Приходите ещё)")
    // Если не хватает средств, то...
    } else if (cost > balance){
    print ("Недостаточно средств. Попробуйте другую карту.")
}
default:
    print("Пользователь,", idUser, ",отсутствует в системе лояльности. Предложите покупателю нашу бонусную карту со скидкой 25% в течение этой недели!")
    
}

var pointsBlueCube = Int.random(in: 1...6)
var pointsRedCube = Int.random(in: 1...6)
 
repeat {
    print(pointsBlueCube, "|", pointsRedCube)
    pointsBlueCube = Int.random(in: 1...6)
    pointsRedCube = Int.random(in: 1...6)
} while pointsBlueCube != pointsRedCube


let text = "The great apple orchard"
var charCount = 0
for _ in 1...text.count {
    charCount += 1
}
    print (charCount)
    
let companyLoyalities = ["Кофе с собой", "Накопительная акция"]
 
for i in 0..<companyLoyalities.count {
    print(companyLoyalities[i])
}

var countDown = 10
while countDown >= 0 {
    print("До запуска осталось: \(countDown)")
    countDown -= 1
}
print("Поехали!")


let numbers = [1, 2, 3, 4, 5, 6]
numbers[3...] // вместо numbers[3..<numbers.endIndex]
// выведется [4, 5, 6]
numbers[3..<numbers.endIndex]

let stringInput = "Следующую подсказку ждите завтра."
let charactersToRemove: [Character] = ["С", "ю", "а", "о", "с", " "]
var cipher = ""
 
for character in stringInput {
    if charactersToRemove.contains(character) {
        continue
    } else {
        cipher.append(character)
    }
}
print(cipher)


private var name = "Alex"
private var surname = "Sav"

func newData (name: inout String, surname: inout String) {
    name = "Алексей"
    surname = "Савельев"
    print("Мои новые данные: \(name) \(surname)")
}
newData(name: &name, surname: &surname)

func moduleInfo(_ topic: String, _ number: Int) -> String {
    "Я изучаю \(topic) из модуля \(number)"
}

let info = moduleInfo("Функции", 13)
print(info)


func coffeeMachine (favoriteCoffee coffee: String, theRightAmountOfWater water: Int, nameONCoffee name: String) -> String {
    ("Прекрасный и армотный кофе сделанный из \(coffee), с объёмом воды \(water), специально для господина \(name)")
}

let results = coffeeMachine(favoriteCoffee: "Арабика", theRightAmountOfWater: 20, nameONCoffee: "Фёдора")
 print(results)


func isEven(number: Int) -> Bool {
    number % 2 == 0
}

func generateNumberString(number: Int, checkFunction: (Int) -> Bool) -> String {
  let isEven = checkFunction(number)
  return isEven ? "Чётное" : "Нечётное"
}
 
let string = generateNumberString(number: 2, checkFunction: isEven)
print(string)

func recursiveCounter(number: Int) {
  if number < 100 {
    recursiveCounter(number: number + 1)
    print(number + 1)
  }
}
recursiveCounter(number: 99)


// Функция объединяет две строки, а потом передаёт результат в замыкание из параметра
func handler(text: String, closure: (String) -> ()) {
  let concatenateStrings = text + "SkillFactory"
  closure(concatenateStrings)
}

handler(text: "Hello ") { text in
  print(text + " I like you!")
}

func summNumbers(numberOne: Int, numberTwo: Int) -> String {
  String(numberOne + numberTwo)
}

func handlerSumNumber(numberOne: Int, numberTwo: Int, closure: (Int, Int) -> String) -> String {
 let ss = String("Your total amount: " + String (closure(numberOne,numberTwo)))
    return ss
}

handlerSumNumber(numberOne: 2, numberTwo: 3) { num1, num2 in
    let res = String("Your total amount: " + String (num1 + num2))
print (res)
    return res
}

//func checkPersonAge (age: Int) -> Bool{
//    age >= 18
//}

func cigaretteVendingMachine (personAge: Int, closure: (Int) -> Bool) {
    if closure (personAge){
        print ("Thank you for purchasing our products, do not forget that smoking is harmful to your health! Have a nice day.")
    
    } else {
        print ("I apologize! But cigarettes are not sold to people under 18!")
    }
}

cigaretteVendingMachine(personAge: 100) { $0 > 18 }

let myClosure: () -> () = {
    print("HI")
}

let calculator: (_ firstNumber: Int, _ secondNumber: Int) -> (Int) = {
    $0 + $1
}

let resultat = calculator (4,5)
print (resultat)

// Массив данных состоящий из "Имя человека, возраст, должность, зарплата (некое число умножается на 3.14)".
// В консоль должна выводится примерно такая строка:
// "Employee" Nikolay, 19, "works as a" developer "with a salary of $" 1,500 "a month".

let salaryCalculation: (_ firstName: String, _ post: String, _ age: Int, _ salary: Double) -> (String) = {firstName,post,age,salary in
    "Employee \(firstName), \(age), works as a \(post) with a salary of $ \(String (salary * 3.14)) a month"
}


print(salaryCalculation ("Alex", "Director", 18, 500))

//Используя каррирование, соедините три строки и выведите их в консоль. Строки:
//
//" Hi, "
//" now I am knowing"
//" currying"

func sumSim (_1:String, _2:String, _3:String) -> String {
    return (_1 + _2 + _3)
}

func sumSim (_1:String, _2:String) -> (String) -> String {
    return { return (_1 + _2 + $0) }
}

let closure = sumSim(_1: " Hi, ", _2: " now I am knowing")
closure (" currying")

let results4 = sumSim(_1: " Hi, ", _2: " now I am knowing", _3: " currying")
print (results4)
print(closure (" currying"))

func test2 (_ text: String) -> (String) -> (String) -> String {
    return { s1 in
        let test2 = text + s1
        return { test2 + $0 }
    }
}
print(test2(" Hi, ")(" now I am knowing")(" currying"))

var pp = "Hello "
 
func increase(_ pp: inout String) {
    pp += "my friend"
}
 
increase(&pp)

func add (brands: String...) {
    for brand in brands {
        print(brand)
    }
}

add(brands: "BMW", "Mercedes", "Mazda", "Toyota")


func getInfo(_ salary: Double) -> (tax: Double, rent: Double){
 
    let tax = salary * 0.13
    let rent = salary * 0.05
    return (tax, rent)
}
 
var losses = getInfo(11000)
 
print("Подоходный налог: \(losses.tax)")
print("Рента: \(losses.rent)")

//MARK: ЗАМЫКАНИЯ

if true {
    let isDivide = { (num1: Int, num2: Int) -> Bool in
        num1 % num2 == 0 }
    
    let isHaveCommonDivider = { (num1: Int, num2: Int) -> Bool in
        let max = [num1, num2].max()!
        let min = [num1, num2].min()!
        
        for num in 2 ... min {
            if num1 % num == 0 && num2 % num == 0 {return true}
        }
        return false
    }
    let isSumOdd = { (num1: Int, num2: Int) -> Bool in (num2 + num1) % 2 == 0 }
    
    func twoNumChecks (_ n1: Int, _ n2: Int, closure: (Int, Int) -> Bool) -> Bool {
        return closure (n1, n2)
    }
    
    twoNumChecks(6, 4, closure: isDivide)
    twoNumChecks(6, 3, closure: isHaveCommonDivider)
    twoNumChecks(6, 1, closure: isSumOdd)
}


