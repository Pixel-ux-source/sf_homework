
import UIKit

//MARK: Строки и подстроки + опционалы
//После чего их надо объелинить в третьей строке, используя извлечение опционального значения. Результат выведи на консоль.
//var one: String? = "I love "
//var two: String? = "SkillFactory"
//
//func unification() {
//    guard let one = one, let two = two else { fatalError("Нет значения") }
//    let three = one + two
//    print (three)
//}
//
//unification()
//
//let someString = """
//Январь
//Февраль
//Март
//Апрель
//Май
//Июнь
//"""
//print(someString)
//
//var someCompany = "\t \r\t\t000\n \t \"bigData\" \r\n- some cool company"
//print (someCompany )

//var someString2 = String()
//func checkEmpty() {
//    if someString2.isEmpty {
//        someString2 = "I love winter ⛄"
//        print(someString2)
//    }
//
//}
//
//checkEmpty()
//
//var iLovwWinter = "I love winter ⛄"
//func printCharactres () {
//    for x in iLovwWinter {
//        print(x)
//    }
//
//}
//printCharactres()
//
//func printCount () {
//    for x in 0 ... iLovwWinter.count {
//        print ("Count simbols: \(x)")
//    }
//}
//printCount()
//
//// Получим второй индекс из слова love
//func printSecondIndex () {
//let charIndex = iLovwWinter.index(iLovwWinter.startIndex, offsetBy: 2)
//    print(iLovwWinter[charIndex])
//}
//printSecondIndex()
//
////Используя приобретенные знания, получите из строки "I love winter ⛄" седьмой символ — W.
//
//func printSeventhSymbol () {
//    let charIndex = iLovwWinter.index(iLovwWinter.startIndex, offsetBy: 7)
//    print(iLovwWinter[charIndex])
//}
//
//printSeventhSymbol()
//
//func addQuestionMarkToEndLine () {
//    iLovwWinter.insert("?", at: iLovwWinter.endIndex)
//    print (iLovwWinter)
//}
//addQuestionMarkToEndLine()
//
//func addQuestionMarkToEndLineTwo () {
//    iLovwWinter.append("?")
//    print (iLovwWinter)
//}
//addQuestionMarkToEndLineTwo()
//
//func removeQuestionMarkFromEndLine () {
//    iLovwWinter.removeLast()
//    print (iLovwWinter)
//}
//removeQuestionMarkFromEndLine()
//
//func addQuestionsAndText () {
//    iLovwWinter.insert (contentsOf: "? No dude, this is joke, i love summer", at: iLovwWinter.index(before: iLovwWinter.endIndex))
//    print (iLovwWinter)
//}
//addQuestionsAndText()
//
//func removeSnowman () {
//    iLovwWinter.remove(at: iLovwWinter.index(before: iLovwWinter.endIndex))
//    print (iLovwWinter)
//}
//removeSnowman()
//
//var snowString = "I love winter? No dude, this is joke, i love summer!⛄"
//func removeSnowmanTwo () {
//    snowString.remove(at: snowString.index(before: snowString.endIndex))
//    print(snowString)
//}
//removeSnowmanTwo()
//
//func removePartOfString () {
//    let range = snowString.index(snowString.endIndex, offsetBy: -38)..<snowString.endIndex
//    snowString.removeSubrange(range)
//}
//removePartOfString()
//print (snowString)
//
//let someString = "Hello my friend, do you like cookies?"
// 
//let index = someString.firstIndex(of: ",") ?? someString.endIndex
//let firstPartOfSentence = someString[..<index]
//let newSomeString = String(firstPartOfSentence)
// 
//print(newSomeString)
//
//
//let firstString = "Hello string!"
//let lastString = "Hello String!"
//func compareTwoStrings() {
//    if firstString != lastString {
//        print("we are NOT identical")
//    } else {
//        print("we are identical")
//    }
//}
//compareTwoStrings()
//
//let char: Character = "a"
//print(char)


// MARK: ЕНУМЫ!

//enum DenominationDollarBills {
//  case one
//  case two
//  case five
//  case ten
//  case twenty
//  case fifty
//  case hundred
//}
//
//
//enum Currencies {
//    enum CountryUsingDollarBills {
//        case australia, usa, canada, mexico
//    }
//    enum CountryUsingRub {
//        case russia, belarus
//    }
//    
//    case dollar (country: String, shortName:String, dollarZone: CountryUsingDollarBills)
//    case euro (country: String, shortName:String )
//    case pound (country: String, shortName:String )
//    case yen (country: String, shortName:String )
//    case rub (country: String, shortName:String, rubZone: CountryUsingRub)
//}
//
//let dollarZone: Currencies
//dollarZone = .dollar(country: "USA", shortName: "USD", dollarZone: .mexico)
//let rubZone: Currencies
//rubZone = .rub(country: "Russia", shortName: "RUR", rubZone: .belarus)
//
//switch dollarZone {
//    
//case let .dollar(country: country, shortName: shortName, dollarZone: dollarZone):
//    print("this is country \(country), used money \(shortName), in the \(dollarZone)")
//    
//case let .euro(country: country, shortName: shortName):
//    print("this is country \(country), used money \(shortName)")
//    
//case let .rub(country: country, shortName: shortName, rubZone: rubZone):
//    print ("this is country \(country), used money \(shortName), in the \(rubZone)")
//    
//case let .pound(country: country, shortName: shortName):
//    print("this is country \(country), used money \(shortName)")
//    
//default:
//    print("EROR TYPE")
//}
//
//enum numbersParticipantsHalfMarathon: Int {
//    case one = 1
//    case two
//    case three
//    case nineHundredNinetyNine = 999
//}
//let number: numbersParticipantsHalfMarathon
//number = .three
//print(number.rawValue)

//MARK: Перечисление шахматных фигур, разделив их по цветам

//enum Chess {
//    enum ColorChess {
//        case white, black
//    }
//    
//    case king (color: ColorChess)
//    case queen (color: ColorChess)
//    case bishop (color: ColorChess)
//    case knight (color: ColorChess)
//    case rook (color: ColorChess)
//    case pawn (color: ColorChess)
//}
//
//func colorChess(_ color: Chess.ColorChess) -> String {
//    switch color {
//    case .white:
//        return "white"
//    case .black:
//        return "black"
//    }
//}
//
//func printChess(_ chess: Chess) {
//    switch chess {
//    case .king(color: let color):
//        print("King \(colorChess(color))")
//    case .queen(color: let color):
//        print("Queen \(colorChess(color))")
//    case .bishop(color: let color):
//        print("Bishop \(colorChess(color))")
//    case .knight(color: let color):
//        print("Knight \(colorChess(color))")
//    case .rook(color: let color):
//        print("Rook \(colorChess(color))")
//    case .pawn(color: let color):
//        print("Pawn \(colorChess(color))")
//    }
//   
//}
//
//printChess(.king(color: .black))
//printChess(.queen(color: .black))
//printChess(.bishop(color: .black))
//printChess(.knight(color: .black))
//printChess(.rook(color: .black))
//printChess(.pawn(color: .black))
//print ("\n")
//printChess(.king(color: .white))
//printChess(.queen(color: .white))
//printChess(.bishop(color: .white))
//printChess(.knight(color: .white))
//printChess(.rook(color: .white))
//printChess(.pawn(color: .white))


//
//enum Chess2: String {
//    enum Color: String {
//        case white
//        case black
//    }
//    
//    case King = "King"
//    case Queen = "Queen"
//    case Bishop = "Bishop"
//    case Knight = "Knight"
//    case Rook = "Rook"
//    case Pawn = "Pawn"
//}
//
//func printChess (figures: String...) {
//    for figure in figures {
//        print (figure)
//    }
//}
//
//let whiteKing = "\(Chess2.Color.white.rawValue): \(Chess2.King.rawValue)"
//let whiteQueen = "\(Chess2.Color.white.rawValue): \(Chess2.Queen.rawValue)"
//let whiteBishop = "\(Chess2.Color.white.rawValue): \(Chess2.Bishop.rawValue)"
//let whiteKnight = "\(Chess2.Color.white.rawValue): \(Chess2.Knight.rawValue)"
//let whiteRook = "\(Chess2.Color.white.rawValue): \(Chess2.Rook.rawValue)"
//let whitePawn = "\(Chess2.Color.white.rawValue): \(Chess2.Pawn.rawValue)"
//
//let blackKing = "\(Chess2.Color.black.rawValue): \(Chess2.King.rawValue)"
//let blackQueen = "\(Chess2.Color.black.rawValue): \(Chess2.Queen.rawValue)"
//let blackBishop = "\(Chess2.Color.black.rawValue): \(Chess2.Bishop.rawValue)"
//let blackKnight = "\(Chess2.Color.black.rawValue): \(Chess2.Knight.rawValue)"
//let blackRook = "\(Chess2.Color.black.rawValue): \(Chess2.Rook.rawValue)"
//let blackPawn = "\(Chess2.Color.black.rawValue): \(Chess2.Pawn.rawValue)"
//
//printChess(figures: whiteKing, whiteQueen, whiteBishop, whiteKnight, whiteRook, whitePawn)
//printChess(figures: blackKing, blackQueen, blackBishop, blackKnight, blackRook, blackPawn)
//
//enum Country: String {
//    case russia = "Russia"
//    case usa = "USA"
//    case canada = "Canada"
//    case paris = "Paris"
//    
//    var description: String {return self.rawValue}
//}
//
//let russia: Country = .russia
//print (russia.description)

//MARK: Напишите перечисление, позволяющее складывать, вычитать и делить числа.
//enum Math {
//    case sum (Double, Double)
//    case divide (Double, Double)
//    case subtract (Double, Double)
//    
//    func calculations (arithmetic: Math) -> Double{
//        switch arithmetic {
//        case let .sum(num1, num2):
//            return num1 + num2
//        case let .divide(num1, num2):
//            return num1 / num2
//        case let .subtract(num1, num2):
//            return num1 - num2
//        }
//    }
//}
//    
//
//
//let sum = Math.sum(2, 2)
//sum.calculations(arithmetic: sum)
//
//let divide = Math.divide(22, 11)
//divide.calculations(arithmetic: divide)
//
//let subtract = Math.subtract(12, 32)
//subtract.calculations(arithmetic: subtract)

// MARK: Жесткая дрочильня с буквой <T>, которую я ещё не понимаю 🥹

//enum Result<T> {
//    case success(T)
//    case failure(String)
//}
//
//func divide(_ dividend: Double, by divisor: Double) -> Result<Double> {
//    if divisor == 0 {
//        return .failure("Division by zero is not allowed.")
//    }
//    
//    let result = dividend / divisor
//    return .success(result)
//}
//
//let result1 = divide(10, by: 2)
//switch result1 {
//case .success(let value):
//    print("Результат: \(value)")
//case .failure(let error):
//    print("Ошибка: \(error)")
//}
//
//let result2 = divide(5, by: 0)
//switch result2 {
//case .success(let value):
//    print("Результат: \(value)")
//case .failure(let error):
//    print("Ошибка: \(error)")
//}


// MARK: Для того, чтобы реализовать данную потребность, нам нужно использовать рекурсивный подход. В перечислениях рекурсивный подход определяется одним ключевым словом перед case: indirect case addition()


//enum Arithmetic {
//    case sum ((Double,Double,Double) -> Double)
//    case divide ((Double,Double,Double) -> Double)
//    case subtract ((Double,Double,Double) -> Double)
//    case sumSubtract ((Double,Double,Double) -> Double)
//}
//let sumArithmetic = Arithmetic.sum ({ a, b, c in
//    return a + b + c
//})
//
//let divideArithmeric = Arithmetic.divide ({ a, b, c in
//    return a / b / c
//})
//
//let subtractArithmetic = Arithmetic.subtract ({ a, b, c in
//    return a - b - c
//})
//
//let sumSubtractArithmetic = Arithmetic.sumSubtract ({ a, b, c in
//    return a + (b - c)
//})
//
//switch sumArithmetic {
//case .sum(let arithmetic):
//    let result = arithmetic(5, 3, 2)
//    print("Result sum is: \(result)")
//case .divide:
//    print("Division is not allowed.")
//case .subtract:
//    print("Subtraction is not allowed.")
//case .sumSubtract:
//    print("SumSubtract is not allowed.")
//}
//
//
//switch divideArithmeric {
//    case .sum:
//    print("Sum is not allowed.")
//case .divide(let arithmetic):
//    let result = arithmetic(5, 3, 2)
//    print("Result divide is: \(result)")
//case .subtract:
//    print("Subtraction is not allowed.")
//case .sumSubtract:
//    print("SumSubtract is not allowed.")
//}
//
//switch subtractArithmetic {
//    case .sum:
//    print("Sum is not allowed.")
//case .divide:
//    print("Division is not allowed.")
//case .subtract(let arithmetic):
//    let result = arithmetic(5, 3, 2)
//    print("Result subtract is: \(result)")
//case .sumSubtract:
//    print("SumSubtract is not allowed.")
//}
//
//switch sumSubtractArithmetic {
//case .sum:
//    print("Sum is not allowed.")
//case .divide:
//    print("Division is not allowed.")
//case .subtract:
//    print("Subtraction is not allowed.")
//case .sumSubtract(let arithmetic):
//    let result = arithmetic(5, 3, 2)
//    print("Result sumSubtract is: \(result)")
//}

//
//// Исходное перечисление
//enum Arithmetic2 {
// 
//  // Член перечисления, который принимает некое значение извне.
//  case number(Float)
//  /*
//   Ассоциированные члены перечисления будут использоваться рекурсивно,
//   для этого мы указываем ключевое слово indirect.
//   В качестве аргумента принимают само перечисление (Arithmetic),
//   но мы указали его при помощи ключевого слова
//   Self - указатель на конкретное перечисление/класс/структуру.
//   */
//  indirect case addition(Self, Self)
//  indirect case subtraction(Self, Self)
//  indirect case division(Self, Self)
//  indirect case multiplication(Self, Self)
// 
//  // Функция выполняющая вычисления.
//  func expression(exp: Arithmetic2) -> Float {
// 
//    // При помощи switch программа выбирает то вычисление которое требуется.
//    switch exp {
//    case .number(let value):
//      return value
// 
//      // Сложение.
//    case let .addition(numberOne, numberTwo):
//      return self.expression(exp: numberOne) + self.expression(exp: numberTwo)
// 
//      // Вычитание.
//    case let .subtraction(numberOne, numberTwo):
//      return self.expression(exp: numberOne) - self.expression(exp: numberTwo)
// 
//      // Умножение.
//    case let .division(numberOne, numberTwo):
//      return self.expression(exp: numberOne) / self.expression(exp: numberTwo)
// 
//      // Деление.
//    case let .multiplication(numberOne, numberTwo):
//      return self.expression(exp: numberOne) * self.expression(exp: numberTwo)
//    }
//  }
//}
// 
//// Создаем экземпляр перечисления, указываем нужное арифметическое действие и передаем значения в качестве аргументов.
//var exp = Arithmetic2.addition(.number(6), .multiplication(.number(10), .number(2)))
// 
//// Получаем результат вычисления.
//exp.expression(exp: exp)


