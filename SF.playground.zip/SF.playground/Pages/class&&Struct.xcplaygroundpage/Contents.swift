
import UIKit

//
//func thisIsFunction() {
//  print("I'm function")
//}
//class IOnlyHaveMethod{
//  func thisIsMethod(){
//    print("I'm method")
//    thisIsFunction()
//  }
//}

//
//Если есть, то выводить:
//
//"vrum vrum vrum vrum vrum"
//"Excellently my car is still alive! I won't be late for work"

//А если бензина совсем не осталось, то:
//
//"kr kr kr kr"
//"Awful! my car is dead, i won't make it to work on time!"

//Начните с создания класса для машины, к примеру, можете назвать его MyCar:
//
//class MyCar {
//}
//
//Уже в теле класса вам необходимо описать всю остальную логику.
//
//Как все будет готово — вызовите ваш метод.
//Метод в этом случае вызывается за пределами тела класса.  Вот так:
//
//class MyCar {
//  }
//
//MyCar().ваш_метод()
//
//class MyCar {
//    var fuel = 0
//    init(fuel: Int = 0) {
//        self.fuel = fuel
//    }
//    func checkFuel() {
//        switch fuel {
//        case 0:
//            print ("kr kr kr kr", "Awful! my car is dead, i won't make it to work on time!")
//        default:
//            print("vrum vrum vrum vrum vrum", "Excellently my car is still alive! I won't be late for work")
//        }
//    }
//}
//
//let myCar = MyCar()
//myCar.fuel = 0
//myCar.checkFuel()
//
//class MyCar2 {
//
//  func startCar(gasolineLiters: Int){
//
//    if gasolineLiters > 0{
//
//      let carStartWork = "vrum vrum vrum vrum vrum"
//
//      let dashboardMessage = "Excellently my car is still alive! I won't be late for work"
//
//      print("\(carStartWork) \(dashboardMessage)")
//
//    } else {
//
//      let carStartWork = "kr kr kr kr"
//
//      let dashboardMessage = "Awful! my car is dead, i won't make it to work on time!"
//
//      print("\(carStartWork) \(dashboardMessage)")
//    }
//
//  }
//}
//
//MyCar2().startCar(gasolineLiters: 01)
 
//struct Menu {
//    let category = "Горячее"
//}
// 
//let menu = Menu()
//print("Раздел меню: \(menu.category)")
// 
//class Restaurant {
//    let menu = Menu()
//    let name = "Rose"
//}
// 
//let restaurant = Restaurant()
//restaurant.menu.category
//restaurant.name


//MARK: Initilizate

//Три метода инициализации :)
//class TestInit {
//    let category: String
//    init() {
//        category = "Hi"
//    }
//}
//TestInit().category


//class TestInit2 {
//    let category: String
//        init(category: String) {
//            self.category = category
//    }
//}
//let test = TestInit2(category: "Hi!")
//test.category


//class TestInit3 {
//    var category: String = "Hi"
//    init(category: String) {
//        self.category = category
//    }
//}
//TestInit3(category: "Hi!?").category


//Метод типа
//class Calculator2 {
//   static var startValueClass = 0   // Почему в классе тоже автоматически инициализируется
//    static func increaseClass (_ valueClass: Int) {
//        startValueClass += valueClass
//        print(startValueClass)
//    }
//}
//
//Calculator2.startValueClass
//Calculator2.increaseClass(2)
//
//
////Метод экземпляра
//class Calculator {
//    var startValue: Int
//    init() {
//        startValue = 0
//    }
//    func increase(_ value: Int) {
//        startValue += value
//        print(startValue)
//    }
//}
//
//let calculator = Calculator ()
//calculator.startValue
//calculator.increase(5)
//
//class Calculator3 {
//    var startValue: Int = 0
//    init(startValue: Int) {
//        self.startValue = startValue
//    }
//    func startValue(_ value: Int) {
//        startValue += value
//        print(startValue)
//    }
//}
//let calculator3 = Calculator3(startValue: 1)
//calculator3.startValue
//
//struct TimesTable {
//    let multiplier: Int
//    subscript(index: Int) -> Int {
//        return multiplier * index // видите? Сабскрипт не будет работать без этого поля
//    }
//}
//let firstNumber = 3
//let secondNumber = 6
//let threeTimesTable = TimesTable(multiplier: firstNumber) // а вот и наша зависимость на практике
//print("\(firstNumber) умножить на \(secondNumber) будет \(threeTimesTable[6])")
//
//class Book{     // класс книги
//     
//    var name: String
//    init(name: String){
//         
//        self.name = name
//    }
//}
//class Library{      // класс библиотеки
//     
//    var books: [Book] = [Book]()
//     
//    init(){
//         
//        books.append(Book(name: "Война и мир"))
//        books.append(Book(name: "Отцы и дети"))
//        books.append(Book(name: "Чайка"))
//    }
//     
//    subscript(index: Int) -> Book{
//         
//        get{
//            return books[index]
//        }
//        set(newValue){
//            books[index] = newValue
//        }
//    }
//}
//
// 
//var myLibrary: Library = Library()
//var firstBook: Book = myLibrary[0]  // получаем элемент по индексу 0
//print(firstBook.name)   // Война и мир
// 
//myLibrary[2] = Book(name: "Мартин Иден")    // установка элемента по индексу 2
//print(myLibrary[2].name)    // Мартин Иден

//class Transoprt {
//    var name: String
//    var maxSpeed: Int
// 
//    init(name: String, maxSpeed: Int) {
//        self.name = name
//        self.maxSpeed = maxSpeed
//    }
// 
//    func printName() {
//        print(self.name)
//    }
//}
// 
//protocol HasPowerReserve {
//    var powerReserve: Double { get }
//}
// 
//class Car: Transoprt, HasPowerReserve {
//    var fuelInTank: Int
//    var fuelConsumption: Double
// 
//    var powerReserve: Double {
//        Double(fuelInTank) / fuelConsumption * 100
//    }
// 
//    init(maxSpeed: Int, fuelInTank: Int, fuelConsumption: Double) {
//        self.fuelInTank = fuelInTank
//        self.fuelConsumption = fuelConsumption
//        super.init(name: "Car", maxSpeed: maxSpeed)
//    }
//}
// 
//let car2 = Car(maxSpeed: 250, fuelInTank: 80, fuelConsumption: 10.5)
//car2.printName()
//print(car2.powerReserve)


//class ElectricScooter: Transoprt, HasPowerReserve  {
//    var chargeLevel: Double
//    var maxDistance: Double
// 
//    var powerReserve: Double {
//        maxDistance * chargeLevel
//    }
// 
//    init(maxSpeed: Int, chargeLevel: Double, maxDistance: Double) {
//        self.chargeLevel = chargeLevel
//        self.maxDistance = maxDistance
//        super.init(name: "ElectricScooter", maxSpeed: maxSpeed)
//    }
//}
// 
//var transports: [HasPowerReserve] = [
//    Car(maxSpeed: 250, fuelInTank: 100, fuelConsumption: 20),
//    ElectricScooter(maxSpeed: 25, chargeLevel: 0.7, maxDistance: 30)
//]
// 
//for transport in transports {
//    print(transport.powerReserve)
//}

//MARK: 1. Создайте структуру Student и заполните её необходимыми свойствами (имя, фамилия, университет, факультет, средний балл и так далее). Создайте несколько студентов и выведите информацию о них в консоль.

struct Student {
    var name: String
    var surname: String
    var university: String
    var faculty: String
    var evaluationsPerSixMounth = [4,5,2,4,3,5,5,5,2,3]
    private var countInEvaluation: Int {
        evaluationsPerSixMounth.count
    }
   private var sum = 0
    private mutating func sumNumberForArray() -> Int{
        for number in evaluationsPerSixMounth {
            sum += number
        }
        return sum
    }
    
    mutating func  middleEvaliation() {
       var results = sumNumberForArray() / countInEvaluation
        print(results)
    }
    
    
    init(name: String, surname: String, university: String, faculty: String, evaluationsPerSixMounth: [Int]) {
        self.name = name
        self.surname = surname
        self.university = university
        self.faculty = faculty
        self.evaluationsPerSixMounth = evaluationsPerSixMounth
    }
    
    
}

var vasyaa = Student(name: "Vasya", surname: "Hz", university: "MoscowGoverment", faculty: "Economy", evaluationsPerSixMounth: [4,5,2,4,3,5,5,5,2,3])
var leha = Student(name: "Leha", surname: "Sav", university: "Tvgu", faculty: "Economy", evaluationsPerSixMounth: [4,5,4,4,4,4,4,4,4,3,2,5])

vasyaa.middleEvaliation()
leha.middleEvaliation()


class Sportsmen {
    var name: String
    var weight: Int
    var height: Int
    func strenght (){
        var results = weight * height / 100
        print(results)
    }
    
    init(name: String, weight: Int, height: Int) {
        self.name = name
        self.weight = weight
        self.height = height
    }
}
class Runner: Sportsmen {
    var Distance: Int
    init(Distance: Int) {
        self.Distance = Distance
        super.init(name: "Alex", weight: 10, height: 10)
    }
    
    override func strenght() {
        var results = "Is low :("
        print(results)
    }
}

//class ProRunner: Sportsmen {
//    
//}
//
//let alex = Sportsmen(name: "ALex", weight: 76, height: 180)
//
//alex.strenght()
//let vasya = Runner(Distance: 22)
//vasya.strenght()
//let igor = ProRunner(name: "Alex", weight: 22, height: 100)

// MARK: Сабскрипы!
//struct Collection {
//    var integers: [Int]
//    
//    subscript (index: Int) -> Int {
//        get {
//            return integers [index]
//        }
//        set {
//            integers [index] = newValue
//        }
//    }
//}
//
//
//
//var one = Collection (integers: [1,2,3,4,5])
//one [3]
//one [3] = 5
//one [3]


// MARK: 3. Создайте класс, внутри которого будет несколько приватных методов или свойств, которые будут что-то возвращать. И один публичный метод, который будет что-то подсчитывать на основе приватных методов или свойств.

//class Transport {
//    var array: [String]
//    var strenght: (Int, String)
//    var color: String
//    var vin: String = ""
//    
//    init(array: [String], strenght: (Int,String), color: String) {
//        self.array = array
//        self.strenght = strenght
//        self.color = color
//        
//    }
//    
//    private func selection() -> String {
//        let stringRepresentation = array.joined(separator:"-")
//        vin = stringRepresentation
//        return vin
//    }
//    
//    func vinSee () {
//        selection ()
//        print(vin)
//    }
//}
//
//let salon = Transport(array: ["9", "3", "1", "3","3","4","5","6","23","11","31","51","1"], strenght: (260, "лс"), color: "Black")
//
//salon.vin
//salon.vinSee()
//
//salon.color
//salon.strenght

class Payment {
    var nameHolder: String
    var numberCard: String
    var cvv: String
    
    init(nameHolder: String, numberCard: String, cvv: String) {
        self.nameHolder = nameHolder
        self.numberCard = numberCard
        self.cvv = cvv
    }
    func payOperation() {
        print("Nice, your name is...\(nameHolder). Good, \(nameHolder), your number card is...\(numberCard) and cvv \(cvv) ")
    }
}

class GiftCard: Payment {
   override func payOperation() {
        print("Good! You got a gift card! Number card is...\(numberCard)")
    }
}



